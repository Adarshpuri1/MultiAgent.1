**Explanation**  
Below is a production‑grade Express.js API that implements the “System Design Generator” feature.  
* A **User** model handles signup/login with JWT authentication and bcrypt password hashing.  
* A **Design** model stores the generated system design (optional, for audit/history).  
* The **POST /api/design/generate** endpoint is protected by JWT, validates the incoming requirement with **Zod**, calls a simple template‑based generator, and returns the full structured design (including a React‑Flow compatible diagram JSON).  
* Centralised error handling, input validation, security best practices (helmet, rate‑limiting, CORS, HTTPS‑ready), and modular routing keep the codebase maintainable and scalable.  

---  

## 1. Server Setup (`src/server.js`)
```javascript
// src/server.js
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import designRoutes from './routes/design.js';
import errorHandler from './middleware/errorHandler.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || '*' }));
app.use(express.json({ limit: '10kb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// DB connection
mongoose
  .connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/design', designRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

// Global error handler
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
```

---  

## 2. User Model (`src/models/User.js`)
```javascript
// src/models/User.js
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, 'Please fill a valid email address'],
    },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ['user', 'admin'], default: 'user' },
  },
  { timestamps: true }
);

// Hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare password method
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

export default mongoose.model('User', userSchema);
```

---  

## 3. Design Model (`src/models/Design.js`)
```javascript
// src/models/Design.js
import mongoose from 'mongoose';

const designSchema = new mongoose.Schema(
  {
    requirement: { type: String, required: true },
    generatedDesign: { type: mongoose.Schema.Types.Mixed, required: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true }
);

export default mongoose.model('Design', designSchema);
```

---  

## 4. JWT Utils (`src/utils/jwt.js`)
```javascript
// src/utils/jwt.js
import jwt from 'jsonwebtoken';

export const generateToken = (payload) =>
  jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '1d' });

export const verifyToken = (token) =>
  jwt.verify(token, process.env.JWT_SECRET);
```

---  

## 5. Auth Middleware (`src/middleware/auth.js`)
```javascript
// src/middleware/auth.js
import { verifyToken } from '../utils/jwt.js';
import User from '../models/User.js';

export const protect = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = verifyToken(token);
      req.user = await User.findById(decoded.id).select('-password');
      if (!req.user) {
        return res.status(401).json({ message: 'User not found' });
      }
      next();
    } catch (err) {
      return res.status(401).json({ message: 'Not authorized, token failed' });
    }
  }

  if (!token) {
    return res.status(401).json({ message: 'Not authorized, no token' });
  }
};
```

---  

## 6. Validation Schema (`src/validation/designValidation.js`)
```javascript
// src/validation/designValidation.js
import { z } from 'zod';

export const generateDesignSchema = z.object({
  requirement: z.string().min(20,
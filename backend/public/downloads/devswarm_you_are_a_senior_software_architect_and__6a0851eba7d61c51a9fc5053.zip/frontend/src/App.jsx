**Explanation**  
The component below is a self‑contained React UI built with Vite, TypeScript, Tailwind CSS, and Framer Motion. It provides a textarea where a user can paste a product requirement, a “Generate Design” button, and a read‑only area that displays the resulting system design in the exact structure requested (overview, functional/non‑functional requirements, HLD, LLD, etc.).  

When the button is clicked, the component simulates the generation process by filling the output with a placeholder design (you can replace the mock data with a real LLM call later). The UI uses Framer Motion’s `motion` components for a smooth fade‑in‑up animation on each section, giving the experience a polished, polished feel.

---  

### SystemDesignGenerator.tsx

```tsx
import { useState } from "react";
import { motion } from "framer-motion";

/**
 * SystemDesignGenerator
 *
 * A reusable component that lets users input a product requirement and
 * displays a formatted system design (HLD, LLD, APIs, etc.) in the
 * structure requested by the prompt.
 *
 * No external props are required – the component manages its own state.
 */
export const SystemDesignGenerator: React.FC = () => {
  const [requirement, setRequirement] = useState<string>("");
  const [generated, setGenerated] = useState<string>("");
  const [loading, setLoading] = useState<boolean>false;

  // -----------------------------------------------------------------
  // Mock generator – replace with actual LLM integration if needed
  // -----------------------------------------------------------------
  const generateDesign = async () => {
    setLoading(true);
    // Simulate network delay
    await new Promise((res) => setTimeout(res, 1500));

    // Placeholder output – in a real app you would feed `requirement`
    // to an LLM and format the response according to the spec.
    const mockDesign = `
# 1. Product Overview
A platform that allows users to create, manage, and share short‑form video clips with integrated music, filters, and social features (likes, comments, follows).

# 2. Functional Requirements
- User registration & authentication (email/social)
- Video upload (max 60 s) with trimming & filters
- Music library integration
- Feed algorithm (personalized For You page)
- Social interactions: like, comment, share, follow
- Search & discovery (hashtags, users, sounds)
- Notifications (push & in‑app)
- Analytics dashboard for creators

# 3. Non Functional Requirements
- Scalability: handle 10M DAU, horizontal scaling
- Availability: 99.9% uptime SLA
- Performance: video start‑up < 2 s, API latency < 200 ms
- Security: OWASP Top 10 compliance, data encryption at rest & in transit
- Maintainability: modular microservices, CI/CD pipeline
- Observability: centralized logging, tracing, metrics

# 4. High Level Architecture (HLD)
The system consists of an API Gateway, several domain‑focused microservices,
a CDN for media, caches, a message queue for async workflows, and
polyglot persistence stores.

{
  "nodes":[
    {"id":"1","type":"service","label":"API Gateway"},
    {"id":"2","type":"service","label":"Auth Service"},
    {"id":"3","type":"service","label":"User Service"},
    {"id":"4","type":"service","label":"Video Service"},
    {"id":"5","type":"service","label":"Feed Service"},
    {"id":"6","type":"service","label":"Notification Service"},
    {"id":"7","type":"service","label":"Analytics Service"},
    {"id":"8","type":"cache","label":"Redis (Session & Feed Cache)"},
    {"id":"9","type":"database","label":"MongoDB (User Metadata)"},
    {"id":"10","type":"database","label":"PostgreSQL (Video Metadata)"},
    {"id":"11","type":"storage","label":"Object Store (S3‑compatible)"},
    {"id":"12","type":"queue","label":"Message Queue (Kafka/RabbitMQ)"},
    {"id":"13","type":"service","label":"CDN (CloudFront/Akamai)"}
  ],
  "edges":[
    {"source":"1","target":"2"},
    {"source":"1","target":"3"},
    {"source":"1","target":"4"},
    {"source":"1","target":"5"},
    {"source":"1","target":"6"},
    {"source":"1","target":"7"},
    {"source":"2","target":"8"},
    {"source":"3","target":"8"},
    {"source":"3","target":"9"},
    {"source":"4","target":"10"},
    {"source":"4","target":"11"},
    {"source":"5","target":"8"},
    {"source":"5","target":"9"},
    {"source":"6","target":"8"},
    {"source":"7","target":"9"},
    {"source":"4","target":"12"},
    {"source":"5","target":"12"},
    {"source":"6","target":"12"},
    {"source":"7","target":"12"},
    {"source":"11","target":"13"},
    {"source":"13","target":"1"}
  ]
}

# 5. Low Level Design (LLD)
- **Auth Service**: Handles OAuth, JWT issuance, refresh tokens, password hashing (bcrypt). Stateless; relies on Redis for session blacklist.
- **User Service**: CRUD ops on user profiles; stores avatar URL, bio, follower counts. Uses MongoDB for flexible schema.
- **Video Service**: Receives upload via multipart/form‑d, stores raw video in Object Store, triggers transcoding pipeline (FFmpeg workers) via Kafka, stores metadata (duration, thumbnail, S3 keys) in PostgreSQL.
- **Feed Service**: Generates personalized feeds using a hybrid of collaborative filtering and ranking; caches top‑N feeds in Redis for hot users; falls back to DB on miss.
- **Notification Service**: Consumes events from Kafka (video‑uploaded, liked, commented) and sends push via FCM/APNS and in‑app notifications via WebSocket.
- **Analytics Service**: Aggregates events (views, likes, shares) into a data warehouse (Snowflake/BigQuery) for batch jobs; provides real‑time counters via Redis Streams.
- **API Gateway**: Handles request routing, rate limiting (token bucket), JWT validation, SSL termination, request/response logging, and static asset serving.

# 6. Microservices
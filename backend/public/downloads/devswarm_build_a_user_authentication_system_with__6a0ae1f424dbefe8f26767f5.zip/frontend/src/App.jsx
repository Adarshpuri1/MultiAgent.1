**Explanation**

Below is a self‑contained React component that implements a full‑flow authentication UI (login, register, password‑reset request, and password‑reset) using JWT.  

* **State & data flow** – A lightweight `AuthContext` holds the JWT token and user info. Custom hooks (`useLogin`, `useRegister`, `useForgotPassword`, `useResetPassword`) wrap the API calls and expose `loading`, `error`, and `success` flags.  
* **UI/UX** – The component uses **Framer Motion** for smooth tab‑switch animations and form‑field entrance effects. Tailwind CSS provides the styling, keeping the design responsive and accessible (proper `<label>` elements, focus‑visible outlines, ARIA live regions for error/success messages).  
* **Extensibility** – The base API URL can be passed via the `apiBase` prop; all endpoints are built from it, making it easy to swap with a mock server or change versions.  

You can drop the `AuthSystem` component into any page (e.g., `<AuthSystem apiBase="/api" />`) and it will handle the auth flow, storing the JWT in `localStorage` and exposing it through the context for the rest of your app.

---

```tsx
// AuthSystem.tsx
import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";

/* ------------------- Types ------------------- */
interface User {
  id: string;
  name: string;
  email: string;
}
interface AuthContextType {
  token: string | null;
  user: User | null;
  login: (token: string, user: User) => void;
  logout: () => void;
}

/* ------------------- Context ------------------- */
const AuthContext = createContext<AuthContextType | undefined>(undefined);
export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

interface AuthProviderProps {
  children: ReactNode;
}
export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("jwtToken"));
  const [user, setUser] = useState<User | null>(null);

  // Hydrate user from token (optional – you could call /me here)
  useEffect(() => {
    if (token) {
      const payload = JSON.parse(atob(token.split(".")[1]));
      setUser({
        id: payload.sub,
        name: payload.name,
        email: payload.email,
      });
    }
  }, [token]);

  const login = (tokenStr: string, userData: User) => {
    setToken(tokenStr);
    setUser(userData);
    localStorage.setItem("jwtToken", tokenStr);
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("jwtToken");
  };

  return (
    <AuthContext.Provider value={{ token, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

/* ------------------- Hooks for API ------------------- */
type UseMutation<TData, TVariables> = {
  data: TData | null;
  loading: boolean;
  error: string | null;
  mutate: (vars: TVariables) => Promise<void>;
  reset: () => void;
};

function useLogin(apiBase: string): UseMutation<{ token: string; user: User }, { email: string; password: string }> {
  const [data, setData] = useState<{ token: string; user: User } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { login } = useAuth();

  const mutate = async (vars) => {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.post(`${apiBase}/auth/login`, vars);
      setData(res.data);
      login(res.data.token, res.data.user);
    } catch (e: any) {
      setError(e.response?.data?.message ?? "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setData(null);
    setLoading(false);
    setError(null);
  };

  return { data, loading, error, mutate, reset };
}

function useRegister(apiBase: string): UseMutation<{ token: string; user: User }, { name: string; email: string; password: string }> {
  const [data, setData] = useState<{ token: string; user: User } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { login } = useAuth();

  const mutate = async (vars) => {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.post(`${apiBase}/auth/register`, vars);
      setData(res.data);
      login(res.data.token, res.data.user);
    } catch (e: any) {
      setError(e.response?.data?.message ?? "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setData(null);
    setLoading(false);
    setError(null);
  };

  return { data, loading, error, mutate, reset };
}

function useForgotPassword(apiBase: string): UseMutation<{ message: string }, { email: string }> {
  const [data, setData] = useState<{ message: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mutate = async (vars) => {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.post(`${apiBase}/auth/forgot-password`, vars);
      setData(res.data);
    } catch (e: any) {
      setError(e.response?.data?.message ?? "Forgot password request failed");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setData(null);
    setLoading(false);
    setError(null);
  };

  return { data, loading, error, mutate, reset };
}

function useResetPassword(apiBase: string): UseMutation<{ message: string }, { token: string; password: string }> {
  const [data, setData] = useState<{ message: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mutate = async (vars) => {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.post(`${apiBase}/auth/reset-password`, vars);
      setData(res.data);
    } catch (e: any) {
      setError(e.response?.data?.message ?? "Password reset failed");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setData(null);
    setLoading(false);
    setError(null);
  };

  return { data, loading, error, mutate, reset };
}

/* ------------------- UI Components -------------------
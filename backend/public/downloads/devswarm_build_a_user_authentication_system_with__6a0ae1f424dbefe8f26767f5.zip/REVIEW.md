**ORION REVIEW – Authentication + Password‑Reset Feature**  
*(Backend = Nexus, Frontend = Aria, Tests = Vera)*  

Below each finding I list:  

* **ID** – a unique reference you can copy‑paste into your tracker.  
* **Severity** – **Critical** (must fix before production), **High** (should fix soon), **Medium** (good‑to‑have), **Low** (nice‑to‑have).  
* **Location** – file / line (or section) where the problem appears.  
* **Description** – what is wrong and why it matters.  
* **Recommendation** – concrete steps to fix it.  

At the end I give a **Conflict Analysis** that highlights any mismatched API contracts between the frontend and the backend.

---

## 1️⃣ Backend (Nexus) – Security & Architecture

| ID | Severity | Location | Issue | Recommendation |
|----|----------|----------|-------|----------------|
| B1 | **Critical** | `src/middleware/auth.js` (truncated in snippet) – missing **token‑validation error handling** and **missing `req.user` attachment**. | If the `verifyAccessToken` throws (expired/invalid token) the async‑handler will pass the error to the error‑middleware, but the middleware does **not** attach the decoded payload to `req.user`. Protected routes that expect `req.user` will receive `undefined`. | After `verifyAccessToken(token)`, do: `req.user = decoded; next();`. Also add a explicit `catch (err) { return res.status(401).json({success:false,message:'Invalid or expired token'}); }` so the error‑handler does not leak stack traces. |
| B2 | **High** | `src/utils/token.js` – **HS256 secret loaded directly from `process.env.JWT_ACCESS_SECRET` with no fallback or validation**. | If the env var is missing or empty, `jwt.sign/verify` will throw a cryptic error that may be exposed in responses (depending on error‑handler). | Validate at startup: `if (!process.env.JWT_ACCESS_SECRET) throw new Error('JWT_ACCESS_SECRET is required');`. Consider using RS256 with a key‑pair for better key‑rotation semantics. |
| B3 | **High** | No **rate‑limiting** on `/auth/login`, `/auth/register`, `/auth/forgot-password`. | Allows brute‑force password guessing, account enumeration (via reset‑email timing), and DoS on the email service. | Add `express-rate-limit` (or similar) – e.g., 5 attempts per 15 min per IP for login, 10 per hour for forgot‑password. |
| B4 | **High** | `src/utils/email.js` – **SMTP transport created at module load time** without checking that required env vars exist. | If any SMTP env var is missing, the transporter will be malformed
**Explanation**

Below is a production‑ready skeleton for a **user authentication + password‑reset** API built with:

| Layer | Technology |
|-------|-------------|
| **Framework** | Express.js |
| **ORM / DB** | Mongoose (MongoDB) |
| **Validation** | Joi (schema‑based request validation) |
| **Authentication** | JSON Web Tokens (signed with HS256, stored in an `Authorization: Bearer <token>` header) |
| **Password security** | bcrypt (salt + hash) |
| **Reset flow** | Crypto‑generated one‑time token, hashed & saved with expiry, sent via nodemailer (placeholder implementation) |
| **Error handling** | Centralised async‑wrapper + error‑handling middleware |
| **Environment** | dotenv for config (JWT secret, email service, etc.) |
| **Security best practices** | • Password never stored in plain text  <br>• JWT short‑lived (15 min) + refresh‑token optional (not shown)  <br>• Reset token hashed before DB storage  <br>• HTTP‑only cookies could be added; here we keep token in header for simplicity  <br>• Input sanitisation via Joi  <br>• Rate‑limiting placeholder (you can plug `express-rate-limit`)  <br>• CORS helmet (you can add `helmet` & `cors`) |

The code is split into logical files for readability, but you can collapse them into a single `server.js` for a quick demo.

---

## 1. Project Structure (suggested)

```
src/
├─ config/
│   └─ db.js                # Mongoose connection
├─ controllers/
│   └─ authController.js    # Route handler logic
├─ middleware/
│   ├─ auth.js              # JWT verification middleware
│   ├─ validate.js          # Joi validator wrapper
│   └─ errorHandler.js      # Central error handler
├─ models/
│   └─ User.js              # Mongoose schema + methods
├─ routes/
│   └─ auth.js              # Express Router definition
├─ utils/
│   ├─ email.js             # Nodemailer wrapper (placeholder)
│   └─ token.js             # JWT sign/verify helpers
├─ .env                     # Environment variables
├─ server.js                # App entry point
└─ package.json
```

---

## 2. Core Files

### 2.1 `src/config/db.js`

```js
// src/config/db.js
const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log(`MongoDB connected: ${conn.connection.host}`);
  } catch (err) {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  }
};

module.exports = connectDB;
```

---

### 2.2 `src/models/User.js`

```js
// src/models/User.js
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email'],
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: 8,
      select: false, // hide by default in queries
    },
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
    },
    // Password reset fields
    resetPasswordToken: String,
    resetPasswordExpires: Date,
  },
  { timestamps: true }
);

/**
 * Hash password before saving
 */
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(12);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

/**
 * Compare candidate password with hashed password
 */
userSchema.methods.matchPassword = async function (enteredPassword) {
  return bcrypt.compare(enteredPassword, this.password);
};

/**
 * Generate a random reset token, hash it, store hash+expiry,
 * return the plain token to be sent to the user.
 */
userSchema.methods.getResetPasswordToken = function () {
  // 32‑byte hex string (~64 chars) – enough entropy
  const resetToken = crypto.randomBytes(32).toString('hex');

  // Hash token and set to resetPasswordToken field
  this.resetPasswordToken = crypto
    .createHash('sha256')
    .update(resetToken)
    .digest('hex');

  // Token expires in 1 hour (adjust as needed)
  this.resetPasswordExpires = Date.now() + 3600000; // 1 hour

  return resetToken;
};

module.exports = mongoose.model('User', userSchema);
```

---

### 2.3 `src/utils/token.js`

```js
// src/utils/token.js
const jwt = require('jsonwebtoken');

/**
 * Sign a JWT (access token)
 * @param {Object} payload  - Usually { userId, email }
 * @returns {string}
 */
const signAccessToken = (payload) => {
  return jwt.sign(payload, process.env.JWT_ACCESS_SECRET, {
    expiresIn: process.env.JWT_ACCESS_EXPIRES_IN || '15m',
  });
};

/**
 * Verify a JWT and return decoded payload or throw
 * @param {string} token
 */
const verifyAccessToken = (token) => {
  return jwt.verify(token, process.env.JWT_ACCESS_SECRET);
};

module.exports = { signAccessToken, verifyAccessToken };
```

---

### 2.4 `src/utils/email.js` (placeholder)

```js
// src/utils/email.js
const nodemailer = require('nodemailer');

// Create transporter using env vars (e.g., SMTP, SendGrid, SES)
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: process.env.SMTP_SECURE === 'true', // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

/**
 * Send an email – keep this simple; you can enrich with templates later.
 * @param {string} to
 * @param {string} subject
 * @param {string} text
 */
const sendEmail = async ({ to, subject, text }) => {
  const mailOptions = {
    from: `"Support" <${process.env.EMAIL_FROM}>`,
    to,
    subject,
    text,
  };

  await transporter.sendMail(mailOptions);
};

module.exports = { sendEmail };
```

---

### 2.5 `src/middleware/validate.js`

```js
// src/middleware/validate.js
const Joi = require('joi');

/**
 * Wrapper to run Joi validation on req.body (or params/query if needed)
 * @param {Joi.ObjectSchema} schema
 */
const validate = (schema) => (req, res, next) => {
  const { error } = schema.validate(req.body, { abortEarly: false });
  if (error) {
    const details = error.details.map((d) => d.message);
    return res.status(400).json({ success: false, errors: details });
  }
  next();
};

module.exports = validate;
```

---

### 2.6 `src/middleware/auth.js`

```js
// src/middleware/auth.js
const { verifyAccessToken } = require('../utils/token');
const asyncHandler = require('express-async-handler');

/**
 * Protect routes – expects Authorization: Bearer <token>
 */
const protect = asyncHandler(async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers
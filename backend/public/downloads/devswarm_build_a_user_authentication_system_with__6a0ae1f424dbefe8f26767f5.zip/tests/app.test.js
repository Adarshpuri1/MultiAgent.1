**Explanation**

Below are three complementary test suites that together give ≥ 80 % coverage of the authentication + password‑reset feature:

| Suite | Tool | What it validates |
|-------|------|-------------------|
| **Unit** | Jest + manual mocks | Isolated controller/service logic (validation, token generation, password‑hashing, reset‑token flow). No network or DB calls. |
| **Integration** | Jest + Supertest + an in‑memory MongoDB (`mongodb-memory-server`) | Full request‑response cycle against a real Express app, but with a temporary DB so tests are fast and repeatable. Covers happy‑paths, validation errors, duplicate‑email, token expiry, etc. |
| **E2E** | Playwright (Chromium) | Browser‑based UI flow using the React `AuthSystem` component (login → register → forgot‑password → reset‑password → accessing a protected page). Confirms that the UI, API, cookies/localStorage and redirects all work together. |

Each test file begins with a short setup block (`beforeAll/afterAll`, `beforeEach/afterEach`) and then groups tests with `describe`. Edge‑cases and error scenarios are included.

> **NOTE** – The test files assume the project structure from the prompt and that the Express app is exported from `src/server.js` (or `src/app.js`). Adjust the import paths if your entry point differs.

---

## 1️⃣ Unit Tests – `src/__tests__/auth.unit.test.js`

```js
// src/__tests__/auth.unit.test.js
/**
 * Unit tests for the authentication logic.
 * Uses plain Jest mocks – no DB, no network.
 */
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { signAccessToken, verifyAccessToken } = require('../utils/token');
const { sendEmail } = require('../utils/email');
const authController = require('../controllers/authController');

jest.mock('../models/User');
jest.mock('../utils/token');
jest.mock('../utils/email');
jest.mock('bcryptjs');
jest.mock('crypto');

describe('Auth Controller – unit', () => {
  let mockReq, mockRes, mockNext;

  beforeEach(() => {
    mockReq = { body: {} };
    mockRes = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };
    mockNext = jest.fn();
    jest.clearAllMocks();
  });

  describe('register', () => {
    it('should hash password and create user', async () => {
      const payload = { name: 'Alice', email: 'a@test.com', password: 'Secret123!' };
      mockReq.body = payload;

      // bcrypt.hash returns a fake hash
      bcrypt.hash.mockResolvedValueAsync('hashedPassword');

      // User.create returns a user object with _id and email
      const createdUser = { _id: 'userid123', ...payload, password: 'hashedPassword' };
      User.create.mockResolvedValue(createdUser);

      // token signing
      signAccessToken.mockReturnValue('fake.jwt.token');

      await authController.register(mockReq, mockRes, mockNext);

      expect(bcrypt.hash).toHaveBeenCalledWith(payload.password, 12);
      expect(User.create).toHaveBeenCalledWith({
        name: payload.name,
        email: payload.email.toLowerCase(),
        password: 'hashedPassword',
      });
      expect(signAccessToken).toHaveBeenCalledWith({
        userId: createdUser._id,
        email: createdUser.email,
      });
      expect(mockRes.status).toHaveBeenCalledWith(201);
      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          token: 'fake.jwt.token',
          user: { id: createdUser._id, name: createdUser.name, email: createdUser.email },
        })
      );
    });

    it('should return 400 on validation error (Joi)', async () => {
      mockReq.body = {}; // missing required fields
      await authController.register(mockReq, mockRes, mockNext);
      expect(mockRes.status).toHaveBeenCalledWith(400);
      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({ success: false, errors: expect.any(Array) })
      );
    });
  });

  describe('login', () => {
    it('should return token when credentials are correct', async () => {
      mockReq.body = { email: 'b@test.com', password: 'rightPass' };
      const fakeUser = {
        _id: 'uid456',
        email: 'b@test.com',
        password: '$2a$12$hashed', // bcrypt hash
        name: 'Bob',
        matchPassword: jest.fn(),
      };
      User.findOne.mockResolvedValue(fakeUser);
      bcrypt.compare.mockResolvedValue(true);
      signAccessToken.mockReturnValue('login.jwt');

      await authController.login(mockReq, mockRes, mockNext);

      expect(User.findOne).toHaveBeenCalledWith({ email: mockReq.body.email.toLowerCase() });
      expect(bcrypt.compare).toHaveBeenCalledWith(mockReq.body.password, fakeUser.password);
      expect(signAccessToken).toHaveBeenCalledWith({ userId: fakeUser._id, email: fakeUser.email });
      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({ success: true, token: 'login.jwt', user: expect.any(Object) })
      );
    });

    it('should return 401 for wrong password', async () => {
      mockReq.body = { email: 'c@test.com', password: 'wrong' };
      const fakeUser = {
        _id: 'uid789',
        email: 'c@test.com',
        password: '$2a$12$hashed',
        matchPassword: jest.fn(),
      };
      User.findOne.mockResolvedValue(fakeUser);
      bcrypt.compare.mockResolvedValue(false);

      await authController.login(mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({ success: false, message: 'Invalid credentials' })
      );
    });
  });

  describe('forgotPassword', () => {
    it('should generate reset token, hash it, save user and call sendEmail', async () => {
      mockReq.body = { email: 'd@test.com' };
      const fakeUser = {
        _id: 'uid111',
        email: 'd@test.com',
        getResetPasswordToken: jest.fn().mockReturnValue('plainToken'),
        save: jest.fn(),
      };
      User.findOne.mockResolvedValue(fakeUser);
      sendEmail.mockResolvedValue();

      await authController.forgotPassword(mockReq, mockRes, mockNext);

      expect(User.findOne).toHaveBeenCalledWith({ email: mockReq.body.email.toLowerCase() });
      expect(fakeUser.getResetPasswordToken).toHaveBeenCalled();
      expect(fakeUser.save).toHaveBeenCalled();
      expect(sendEmail).toHaveBeenCalledWith(
        expect.objectContaining({
          to: fakeUser.email,
          subject: expect.stringContaining('Password Reset'),
          text: expect.stringContaining('plainToken'),
        })
      );
      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({ success: true, message: expect.stringContaining('reset link') })
      );
    });

    it('should return 404 if user not found', async () => {
      mockReq.body = { email: 'unknown@test.com' };
      User.findOne.mockResolvedValue(null);

      await authController.forgotPassword(mockReq, mockRes, mockNext);

      expect(mockRes.status).toHaveBeenCalledWith(404);
      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({ success: false, message: 'User not found' })
      );
    });
  });

  describe('resetPassword', () => {
    it('should reset password when token is valid and not expired', async () => {
      mockReq.body = { token: 'hashedResetToken', password: 'NewPass!123' };
      const fakeUser = {
        _id: 'uid2